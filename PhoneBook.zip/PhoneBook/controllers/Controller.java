package PhoneBook.controllers;

import PhoneBook.models.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.FileNotFoundException;

public class Controller {
    private ObservableList<Book> Data = FXCollections.observableArrayList();

    @FXML
    private TableView<Book> table;

    @FXML
    private TableColumn<Book, Integer> id;

    @FXML
    private TableColumn<Book, String> from;

    @FXML
    private TableColumn<Book, String> to;

    @FXML
    private TableColumn<Book, String> date;

    @FXML
    private TableColumn<Book, String> time;

    @FXML
    private TableColumn<Book, Double> duration;

    @FXML
    private void initialize() throws FileNotFoundException {
        initData();
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        from.setCellValueFactory(new PropertyValueFactory<>("from"));
        to.setCellValueFactory(new PropertyValueFactory<>("to"));
        date.setCellValueFactory(new PropertyValueFactory<>("date"));
        time.setCellValueFactory(new PropertyValueFactory<>("time"));
        duration.setCellValueFactory(new PropertyValueFactory<>("duration"));

        table.setItems(Data);
    }

    private void initData() {
        Data.add(new Book(1, "Vasya", "Petya", "01.12.2018", "13:00", 60));
        Data.add(new Book(2, "Petya", "Vasya", "01.12.2018", "13:20", 5));
        Data.add(new Book(3, "Masha", "Petya", "01.12.2018", "13:30", 45));
        Data.add(new Book(4, "Katya", "Anya", "01.12.2018", "13:40", 56));
        Data.add(new Book(5, "Vanya", "Luda", "01.12.2018", "15:00", 43));
    }
}